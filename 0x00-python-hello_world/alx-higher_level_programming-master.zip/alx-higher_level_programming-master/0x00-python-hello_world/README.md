##0x00-python-hello_world README.md##
This directory contains scripts and programs that cover basic Python concepts.

##0-run##
A Shell script that runs a Python script and Python filename is saved in the 
environment variable $PYFILE
