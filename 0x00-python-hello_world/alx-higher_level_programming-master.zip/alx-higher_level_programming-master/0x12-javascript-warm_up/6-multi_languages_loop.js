#!/usr/bin/node

const myStr = ['C is fun', 'Python is cool', 'JavaScript is amazing'];
let idx = 0;

while (idx < 3) {
  console.log(myStr[idx]);
  idx++;
}
