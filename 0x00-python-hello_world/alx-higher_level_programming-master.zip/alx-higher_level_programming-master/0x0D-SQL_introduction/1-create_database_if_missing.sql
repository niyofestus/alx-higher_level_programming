-- creates database if it doesn't exist.
CREATE DATABASE IF NOT EXISTS hbtn_0c_0;
