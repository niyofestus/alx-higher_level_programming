-- Update the score of Bob to 10 in the table 'second_table'
-- in the database hbtn_0c_0
UPDATE second_table
SET
score = 10
WHERE name = "Bob";
