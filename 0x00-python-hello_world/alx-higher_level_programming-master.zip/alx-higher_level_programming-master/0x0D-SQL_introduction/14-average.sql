-- Computes average scores of records in 'second_table'
-- of the database hbtn_0c_0
SELECT AVG(score) 'average'
FROM second_table;
