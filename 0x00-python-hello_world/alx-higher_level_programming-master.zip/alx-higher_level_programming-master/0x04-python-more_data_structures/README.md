This directory covers data structures concepts as implemented in Python 3.4 high-level programming language.
