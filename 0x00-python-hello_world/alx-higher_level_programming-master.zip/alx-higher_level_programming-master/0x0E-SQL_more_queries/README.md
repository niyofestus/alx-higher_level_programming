# OXOE. SQL - More Queries
This directory explores more complex SQL queries and their implementations.

