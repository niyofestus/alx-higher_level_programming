-- insert a new row in the table 'first_table' in the database hbtn_0c_0
INSERT INTO first_table (id, name) VALUES (89, "Holberton School");
