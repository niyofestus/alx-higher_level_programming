-- displays number of records with id=89 in first_table
-- in the database hbtn_0c_0
SELECT COUNT(*) FROM first_table WHERE id=89;
