#!/usr/bin/python3
"""
Contains a definition for an empty Class Rectangle.
"""


class Rectangle:
    """Empty class"""
    pass
