#!/usr/bin/python3
"""Square module."""


class Square:
