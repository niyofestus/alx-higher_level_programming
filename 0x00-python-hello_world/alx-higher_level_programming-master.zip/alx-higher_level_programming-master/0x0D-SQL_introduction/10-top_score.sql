-- lists all records of 'second_table' of database hbtn_0c_0
-- in descending order on the 'score' column
SELECT score, NAME
FROM second_table
ORDER BY score DESC;
