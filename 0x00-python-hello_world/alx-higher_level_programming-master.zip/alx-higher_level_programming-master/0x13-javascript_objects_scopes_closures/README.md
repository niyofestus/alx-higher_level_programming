# 0x13. JavaScript - Object Scopes and Closures.
This directory covers OOP aspect of JavaScript and specifically how to create objects and closures and in so doing using the prototype property to inherit attributes from other objects.
