# 0x0F. Object Relational Mapping.
Object Relational Mapping in Python.
