-- Create table in the specified database on MySQL server
CREATE TABLE IF NOT EXISTS first_table (id INT,
name VARCHAR(256));
