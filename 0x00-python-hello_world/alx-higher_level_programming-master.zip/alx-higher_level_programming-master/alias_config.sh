#!/bin/bash

alias gs="git status" 
alias gc="git commit -m" 
alias ga="git add" 
alias gp="git push -u origin master"
alias ex="chmod a+x"
alias cmp="gcc -Wall -Werror -Wextra -pedantic"

