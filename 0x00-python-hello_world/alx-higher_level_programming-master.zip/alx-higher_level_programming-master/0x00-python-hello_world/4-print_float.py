#!/usr/bin/python3
number = 3.14159
print("Float: {:0.2f}".format(number))
