# 0x08. Python - More Classes.
This directory contains functions and programs that demonstrate advanced Python capabilities in manipulating classes & objects and class instances and covers the following concepts.

i. Class attributes and methods.
ii. Static methods.
iii. __str__ and __repr__ methods.
