-- deletes a database if it exists
DROP DATABASE IF EXISTS hbtn_0c_0;
