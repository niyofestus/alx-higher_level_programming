This directory contains Python scripts that cover module importation and implementation as executed in Python 3.4.
