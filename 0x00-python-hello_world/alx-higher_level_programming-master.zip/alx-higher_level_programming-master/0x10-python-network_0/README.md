# 0x10. Python -Network #0
This directory explore the use to cURL in debugging network links.
