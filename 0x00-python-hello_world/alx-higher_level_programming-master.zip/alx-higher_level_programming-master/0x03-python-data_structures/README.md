This directory contains programs that cover various data structures concepts that are written in Python 3.4
