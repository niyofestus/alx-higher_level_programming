# 0X12. Javascript - Warm Up
This directory contains asic programs that serve as a primer to Javascript.

[![js-semistandard-style](https://raw.githubusercontent.com/standard/semistandard/master/badge.svg)](https://github.com/standard/semistandard)

## Background Context

JavaScript is used for many things. At Holberton School, you will use JavaScript for 2 reasons:

    Scripting (same as we did with Python)
    Web front-end

For the moment, and for learning all basic concepts of this language, we will do some scripting. After, we will make our AirBnB project dynamic by using Javascript and JQuery.
