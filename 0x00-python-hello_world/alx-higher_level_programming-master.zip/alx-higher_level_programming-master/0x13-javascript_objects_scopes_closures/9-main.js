#!/usr/bin/node
const logMe = require('./9-logme').logMe;

logMe('Hello');
logMe('Holberton');
logMe('School');
