-- lists all databases on my MySQL server
SHOW DATABASES;
