#!/usr/bin/node
const add = require('./13-add').add;
console.log(add(3, 5));
