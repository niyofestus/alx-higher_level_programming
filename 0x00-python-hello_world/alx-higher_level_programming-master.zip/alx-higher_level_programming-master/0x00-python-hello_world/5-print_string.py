#!/usr/bin/python3
str = "Holberton School"
print("{:s}{:s}{:s}".format(str, str, str))
print("{:.9s}".format(str))
