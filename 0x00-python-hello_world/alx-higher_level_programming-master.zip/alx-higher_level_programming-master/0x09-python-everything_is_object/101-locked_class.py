#!/usr/bin/python3
    """
    Definition for a LockedClass class.
    """


    class LockedClass:
        """LockedClass class that defines 1 attribute"""

        __slots__ = ['first_name']
